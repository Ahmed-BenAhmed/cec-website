document.addEventListener("DOMContentLoaded", () => {
    const milestonesData = [
        {
            "caption": "شكر كبير لكم! 🌟\nتحية لكل طلبة ENSA BERRCHID لي حضرو معانا فعاليات GeeksBlabla On Campus! كان لقاء مميز وغني بالمعلومات.\nشكر خاص ليوسف العزيزي ومحمد الداودي على مشاركتهم القيمة، وشكر كذلك لإدارة ENSA BERRCHID على دعمهم واستضافتهم.\nمتشوقين للقاءات المقبلة معكم! 💻🚀\n#GeeksBlabla #ENSABerrchid",
            "image_url": "https://instagram.frak2-1.fna.fbcdn.net/v/t51.2885-15/481970400_18073199752749411_7092310395732103669_n.jpg?stp=dst-jpg_e35_tt6&efg=eyJ2ZW5jb2RlX3RhZyI6IkNBUk9VU0VMX0lURU0uaW1hZ2VfdXJsZ2VuLjE0NDB4MTgwMC5zZHIuZjc1NzYxLmRlZmF1bHRfaW1hZ2UifQ&_nc_ht=instagram.frak2-1.fna.fbcdn.net&_nc_cat=103&_nc_oc=Q6cZ2QE3ySzegPSXZLa7IlrlI_iRb2mXsC8nD5U912QXBjaDn6utg7rRwNjMTtoKcDxpvbY&_nc_ohc=EjwEH4m0894Q7kNvwEBmKWU&_nc_gid=Ji67HspRKjDfMh8d5_ol8w&edm=AP4sbd4BAAAA&ccb=7-5&ig_cache_key=MzU3ODIzOTU3MTA4NDM3NjU4OQ%3D%3D.3-ccb7-5&oh=00_AfQzqEotSwXICrYkLmmZkW5_lyBESwi5u0lho-IuvcC7Jg&oe=68745E29&_nc_sid=7a9f4b",
            "timestamp": null
        },
        {
            "caption": "🚀 CodEC : Share & innovation ! 💻\n\nUn immense merci à communauté GeeksBlabla et spécialement à Youssef El azizi  et Mohammed Doaudi pour avoir partagé leur expertise et leurs précieux conseils lors de cette conférence 💛✨ . \n\n👏 Un grand merci également à tous les participants pour leur engagement et leurs questions pertinentes. Votre interaction a rendu cette session encore plus riche et dynamique !\n\n#CodEC #Cec #SoftwareDevelopment #ComputerScience #DevOps #MobileDevelopment #Learning",
            "image_url": "https://instagram.frak2-2.fna.fbcdn.net/v/t51.2885-15/482389522_17963578019855498_4336611377073904465_n.jpg?stp=dst-jpg_e35_tt6&efg=eyJ2ZW5jb2RlX3RhZyI6IkNBUk9VU0VMX0lURU0uaW1hZ2VfdXJsZ2VuLjE0NDB4MTgwMC5zZHIuZjc1NzYxLmRlZmF1bHRfaW1hZ2UifQ&_nc_ht=instagram.frak2-2.fna.fbcdn.net&_nc_cat=102&_nc_oc=Q6cZ2QE3ySzegPSXZLa7IlrlI_iRb2mXsC8nD5U912QXBjaDn6utg7rRwNjMTtoKcDxpvbY&_nc_ohc=BbueYk41iHMQ7kNvwEyqv0a&_nc_gid=Ji67HspRKjDfMh8d5_ol8w&edm=AP4sbd4BAAAA&ccb=7-5&ig_cache_key=MzU3Nzk5ODI1MjE0NzE3MjUwMQ%3D%3D.3-ccb7-5&oh=00_AfQv4QdOS5YIMPjXCseBXCcMW8jjF20-xB4N1TDsAIbf5w&oe=68745EF7&_nc_sid=7a9f4b",
            "timestamp": null
        },
        {
            "caption": "Photo shared by GeeksBlabla #BlablaConf on February 25, 2025 tagging @cec_ensab. Aucune description de photo disponible..",
            "image_url": "https://instagram.frak2-1.fna.fbcdn.net/v/t51.2885-15/481134086_18072826858749411_7262054947492562957_n.jpg?stp=dst-jpg_e35_tt6&efg=eyJ2ZW5jb2RlX3RhZyI6IkZFRUQuaW1hZ2VfdXJsZ2VuLjE0NDB4MTgwMC5zZHIuZjc1NzYxLmRlZmF1bHRfaW1hZ2UifQ&_nc_ht=instagram.frak2-1.fna.fbcdn.net&_nc_cat=103&_nc_oc=Q6cZ2QFIh8Qq_7LZVVSpolSc-GzjfqDTcNOetB1sva7nWnJlR1p8RQKxzreLsc9Xo237g1M&_nc_ohc=YAhLn4HSsx4Q7kNvwHfK5O4&_nc_gid=UluV_3waTKA_C5jmR5W-Qw&edm=APoiHPcBAAAA&ccb=7-5&ig_cache_key=MzU3NTY5NDkzNjU1ODU3ODMyMg%3D%3D.3-ccb7-5&oh=00_AfS4B6p5xZPsATz81sYWDb3lhEatqsaXan71bV_6MmUWww&oe=68745C58&_nc_sid=22de04",
            "timestamp": "February 25, 2025"
        },
        {
            "caption": "Photo shared by Computer  Engineering Club Ensab on December 26, 2024 tagging @othmanotana, @hicham_maghraoui, @ismailhamdach, and @ensaberrechid. Aucune description de photo disponible..",
            "image_url": "https://instagram.frak2-2.fna.fbcdn.net/v/t51.2885-15/470971610_17956341911855498_8289322465913417757_n.jpg?stp=dst-jpg_e35_tt6&efg=eyJ2ZW5jb2RlX3RhZyI6IkZFRUQuaW1hZ2VfdXJsZ2VuLjEwODB4MTA4MC5zZHIuZjc1NzYxLmRlZmF1bHRfaW1hZ2UifQ&_nc_ht=instagram.frak2-2.fna.fbcdn.net&_nc_cat=102&_nc_oc=Q6cZ2QFIh8Qq_7LZVVSpolSc-GzjfqDTcNOetB1sva7nWnJlR1p8RQKxzreLsc9Xo237g1M&_nc_ohc=c6QrDpnHyJgQ7kNvwFCgyOH&_nc_gid=UluV_3waTKA_C5jmR5W-Qw&edm=APoiHPcBAAAA&ccb=7-5&ig_cache_key=MzUzMTcyODA4NjYzNjEyNDM5OA%3D%3D.3-ccb7-5&oh=00_AfSiWf9OZg8-oIq526AYZyjJ8CvPzoA9cXDS7q2hz-PAOQ&oe=68744740&_nc_sid=22de04",
            "timestamp": "December 26, 2024"
        },
        {
            "caption": "✨ Retour sur notre session introductive à la Big Data et l’Intelligence Artificielle ✨\n\nUn grand merci à Marwa et Hafid pour avoir animé cette session captivante qui a plongé nos participants dans les fondamentaux de deux domaines clés du futur :\n\n💾 Big Data : Avec Marwa, nous avons exploré les bases de la gestion et de l’analyse de données massives, en découvrant les outils et méthodologies pour transformer les données en valeur.\n\n🤖 Intelligence Artificielle : Hafid nous a guidés dans le monde fascinant de l’IA, en expliquant ses concepts fondamentaux et en partageant un roadmap clair pour débuter dans ce domaine.\n\nMerci à tous les participants pour leur présence active et leurs échanges enrichissants. Continuons à bâtir ensemble nos compétences dans ces domaines en constante évolution ! 🚀\n\n#BigData #IntelligenceArtificielle #Workshop #Innovation #TechnologiesDuFutur",
            "image_url": "https://instagram.frak2-2.fna.fbcdn.net/v/t51.2885-15/470938269_17955493367855498_9164796804757352630_n.jpg?stp=dst-jpg_e35_tt6&efg=eyJ2ZW5jb2RlX3RhZyI6IkNBUk9VU0VMX0lURU0uaW1hZ2VfdXJsZ2VuLjE0NDB4MTgwMC5zZHIuZjc1NzYxLmRlZmF1bHRfaW1hZ2UifQ&_nc_ht=instagram.frak2-2.fna.fbcdn.net&_nc_cat=102&_nc_oc=Q6cZ2QFIh8Qq_7LZVVSpolSc-GzjfqDTcNOetB1sva7nWnJlR1p8RQKxzreLsc9Xo237g1M&_nc_ohc=Pth9LvJUJdEQ7kNvwGj2xgT&_nc_gid=UluV_3waTKA_C5jmR5W-Qw&edm=APoiHPcBAAAA&ccb=7-5&ig_cache_key=MzUyNjY5MTU2MjUwOTAwNTE3Nw%3D%3D.3-ccb7-5&oh=00_AfRkKkld2pZruVYfCaza7EORZxAsspNJwDvSir7PBsUSTA&oe=68746767&_nc_sid=22de04",
            "timestamp": null
        },
        {
            "caption": "Photo shared by Computer  Engineering Club Ensab on December 16, 2024 tagging @marwakharbichi, @haf0g, and @ensaberrechid. Aucune description de photo disponible..",
            "image_url": "https://instagram.frak2-2.fna.fbcdn.net/v/t51.2885-15/470679100_17955157265855498_2197401869829823605_n.jpg?stp=dst-jpg_e35_tt6&efg=eyJ2ZW5jb2RlX3RhZyI6IkZFRUQuaW1hZ2VfdXJsZ2VuLjEwODB4MTA4MC5zZHIuZjc1NzYxLmRlZmF1bHRfaW1hZ2UifQ&_nc_ht=instagram.frak2-2.fna.fbcdn.net&_nc_cat=102&_nc_oc=Q6cZ2QFIh8Qq_7LZVVSpolSc-GzjfqDTcNOetB1sva7nWnJlR1p8RQKxzreLsc9Xo237g1M&_nc_ohc=PxX7Q9otiQYQ7kNvwG_xWKV&_nc_gid=UluV_3waTKA_C5jmR5W-Qw&edm=APoiHPcBAAAA&ccb=7-5&ig_cache_key=MzUyNDU0Njk5NzQyNTMzNzczNA%3D%3D.3-ccb7-5&oh=00_AfT_DzM86v9K7CFPYiR_leYUwBKxUv8SOjjG9-tf0288rA&oe=68743CEC&_nc_sid=22de04",
            "timestamp": "December 16, 2024"
        },
        {
            "caption": "Photo shared by Computer  Engineering Club Ensab on November 30, 2024 tagging @ensaberrechid, and @orewa.js. Aucune description de photo disponible..",
            "image_url": "https://instagram.frak2-2.fna.fbcdn.net/v/t51.2885-15/468786172_17953226060855498_6320849272588765192_n.jpg?stp=dst-jpg_e35_tt6&efg=eyJ2ZW5jb2RlX3RhZyI6IkZFRUQuaW1hZ2VfdXJsZ2VuLjEwODB4MTA4MC5zZHIuZjc1NzYxLmRlZmF1bHRfaW1hZ2UifQ&_nc_ht=instagram.frak2-2.fna.fbcdn.net&_nc_cat=102&_nc_oc=Q6cZ2QFIh8Qq_7LZVVSpolSc-GzjfqDTcNOetB1sva7nWnJlR1p8RQKxzreLsc9Xo237g1M&_nc_ohc=ya9Fg1CdpiEQ7kNvwHZ6FvY&_nc_gid=UluV_3waTKA_C5jmR5W-Qw&edm=APoiHPcBAAAA&ccb=7-5&ig_cache_key=MzUxMjkxNjQ2Njk1MDcxMTYzOQ%3D%3D.3-ccb7-5&oh=00_AfRQYTMJHfuS_o7jF_25_6gK7mbZQ9A-PoVn79d53RXuGg&oe=6874480B&_nc_sid=22de04",
            "timestamp": "November 30, 2024"
        },
        {
            "caption": "🎉 Retour sur notre session Portfolio ! 🎉\n\nNotre workshop de création de portfolios s’est déroulé dans une ambiance collaborative et pleine d’énergie ! 💼✨\nLes participants ont pu poser les premières bases de leur portfolio, un outil clé pour valoriser leurs compétences et projets.\n\n.\n\n#cec #cec_2024_2025 #WorkshopPortfolio #CréationPortfolio #ApprentissageEnsemble #Succès",
            "image_url": "https://instagram.frak2-2.fna.fbcdn.net/v/t51.2885-15/467747208_17952139922855498_399169980385857847_n.jpg?stp=dst-jpg_e35_tt6&efg=eyJ2ZW5jb2RlX3RhZyI6IkNBUk9VU0VMX0lURU0uaW1hZ2VfdXJsZ2VuLjE0NDB4MTgwMC5zZHIuZjc1NzYxLmRlZmF1bHRfaW1hZ2UifQ&_nc_ht=instagram.frak2-2.fna.fbcdn.net&_nc_cat=102&_nc_oc=Q6cZ2QFIh8Qq_7LZVVSpolSc-GzjfqDTcNOetB1sva7nWnJlR1p8RQKxzreLsc9Xo237g1M&_nc_ohc=VPieFPcUS6YQ7kNvwEEDFzN&_nc_gid=UluV_3waTKA_C5jmR5W-Qw&edm=APoiHPcBAAAA&ccb=7-5&ig_cache_key=MzUwNjQzMjcwNjc1MTExMjM2MQ%3D%3D.3-ccb7-5&oh=00_AfQK2VoE3uPGHOf57rYWbFEX0UlAdiqZ-C3XXHixFNowag&oe=68745F3E&_nc_sid=22de04",
            "timestamp": null
        },
        {
            "caption": "Photo by Computer  Engineering Club Ensab on November 19, 2024. Aucune description de photo disponible..",
            "image_url": "https://instagram.frak2-2.fna.fbcdn.net/v/t51.2885-15/467745356_17951898557855498_2518922426734657772_n.jpg?stp=dst-jpg_e35_tt6&efg=eyJ2ZW5jb2RlX3RhZyI6IkZFRUQuaW1hZ2VfdXJsZ2VuLjEwODB4MTA4MC5zZHIuZjc1NzYxLmRlZmF1bHRfaW1hZ2UifQ&_nc_ht=instagram.frak2-2.fna.fbcdn.net&_nc_cat=102&_nc_oc=Q6cZ2QFIh8Qq_7LZVVSpolSc-GzjfqDTcNOetB1sva7nWnJlR1p8RQKxzreLsc9Xo237g1M&_nc_ohc=_h1JirEHX0gQ7kNvwGH-344&_nc_gid=UluV_3waTKA_C5jmR5W-Qw&edm=APoiHPcBAAAA&ccb=7-5&ig_cache_key=MzUwNDk1MzYxNzg0MjE5NTgwNQ%3D%3D.3-ccb7-5&oh=00_AfSWW5voEFOYTZq9xCpb-7L2DPZYQXkWfYjIH8DHJ5V80g&oe=68744DF1&_nc_sid=22de04",
            "timestamp": "November 19, 2024"
        },
        {
            "caption": "Photo shared by Computer  Engineering Club Ensab on November 06, 2024 tagging @cec_ensab. Aucune description de photo disponible..",
            "image_url": "https://instagram.frak2-2.fna.fbcdn.net/v/t51.2885-15/465930129_17950298669855498_3630048926813910606_n.jpg?stp=dst-jpg_e35_tt6&efg=eyJ2ZW5jb2RlX3RhZyI6IkZFRUQuaW1hZ2VfdXJsZ2VuLjkzNng5MzMuc2RyLmY3NTc2MS5kZWZhdWx0X2ltYWdlIn0&_nc_ht=instagram.frak2-2.fna.fbcdn.net&_nc_cat=102&_nc_oc=Q6cZ2QFIh8Qq_7LZVVSpolSc-GzjfqDTcNOetB1sva7nWnJlR1p8RQKxzreLsc9Xo237g1M&_nc_ohc=o5BO-CPuxTgQ7kNvwGBgpUE&_nc_gid=UluV_3waTKA_C5jmR5W-Qw&edm=APoiHPcBAAAA&ccb=7-5&ig_cache_key=MzQ5NTQ0NDg3MTMxNTIyMzM5NQ%3D%3D.3-ccb7-5&oh=00_AfTD_ricyXwLWf9qsYxzTvq6sqJe26_kY0fBPSt-zENY4A&oe=68745F96&_nc_sid=22de04",
            "timestamp": "November 06, 2024"
        },
        {
            "caption": "Les 3 sessions de notre formation en développement web avec @fakhredine_codes viennent de se terminer avec succès ! De HTML à CSS en passant par JavaScript, nos participants ont acquis les bases essentielles pour se lancer.\n\nNous avons créé une roadmap spéciale pour vous guider et renforcer vos compétences en web ! 🚀\n\nUn grand bravo à tous les participants et un immense merci à Fakhredine pour son expertise et son dévouement. \n\nRestez connectés pour plus d’événements et de formations ! 🌐✨\n\n#webdevelopement #html #css #javascript #cec #cecensab_2024_2025 \n#RécapWorkshop #DéveloppementWeb #DéveloppementMobile #Apprentissage",
            "image_url": "https://instagram.frak2-2.fna.fbcdn.net/v/t51.2885-15/465586329_17949820214855498_8486695114916142902_n.jpg?stp=dst-jpg_e35_tt6&efg=eyJ2ZW5jb2RlX3RhZyI6IkNBUk9VU0VMX0lURU0uaW1hZ2VfdXJsZ2VuLjEwODB4MTA4MC5zZHIuZjc1NzYxLmRlZmF1bHRfaW1hZ2UifQ&_nc_ht=instagram.frak2-2.fna.fbcdn.net&_nc_cat=102&_nc_oc=Q6cZ2QGgCQ7xdOGhycLiwDECFcNAJrJhFticEstcdfk_eyRgpbFCFQvHGkwULHnH9fPKHCY&_nc_ohc=Scmknpm6ZyYQ7kNvwFA3-nq&_nc_gid=_sfYE_Nh4MPaSWuCu90ThA&edm=APoiHPcBAAAA&ccb=7-5&ig_cache_key=MzQ5MjU5MDcwMTM1Njg4NDE1MA%3D%3D.3-ccb7-5&oh=00_AfS0UiymeXEHLJ4UcYNejDQzNHTvuDqX-cIsK7X9Y-w0ag&oe=68745584&_nc_sid=22de04",
            "timestamp": null
        },
        {
            "caption": "Photo shared by Computer  Engineering Club Ensab on October 28, 2024 tagging @fakhredine_codes. Aucune description de photo disponible..",
            "image_url": "https://instagram.frak2-2.fna.fbcdn.net/v/t51.2885-15/464872949_17949180986855498_701981114096924003_n.jpg?stp=dst-jpg_e35_tt6&efg=eyJ2ZW5jb2RlX3RhZyI6IkZFRUQuaW1hZ2VfdXJsZ2VuLjEwODB4MTA4MC5zZHIuZjc1NzYxLmRlZmF1bHRfaW1hZ2UifQ&_nc_ht=instagram.frak2-2.fna.fbcdn.net&_nc_cat=102&_nc_oc=Q6cZ2QGgCQ7xdOGhycLiwDECFcNAJrJhFticEstcdfk_eyRgpbFCFQvHGkwULHnH9fPKHCY&_nc_ohc=w6eUeBbdq20Q7kNvwG3qABS&_nc_gid=_sfYE_Nh4MPaSWuCu90ThA&edm=APoiHPcBAAAA&ccb=7-5&ig_cache_key=MzQ4ODk2NjQ5MjMxNTY2NjUzOA%3D%3D.3-ccb7-5&oh=00_AfRSO507a23QmkZUEpiUAsuBX98h9qsjk1I6jk4gDcNLyg&oe=68744481&_nc_sid=22de04",
            "timestamp": "October 28, 2024"
        },
        {
            "caption": "Photo shared by Computer  Engineering Club Ensab on October 23, 2024 tagging @fakhredine_codes. Aucune description de photo disponible..",
            "image_url": "https://instagram.frak2-2.fna.fbcdn.net/v/t51.2885-15/464369815_17948472947855498_966462801959628470_n.jpg?stp=dst-jpg_e35_tt6&efg=eyJ2ZW5jb2RlX3RhZyI6IkZFRUQuaW1hZ2VfdXJsZ2VuLjEwODB4MTA4MC5zZHIuZjc1NzYxLmRlZmF1bHRfaW1hZ2UifQ&_nc_ht=instagram.frak2-2.fna.fbcdn.net&_nc_cat=102&_nc_oc=Q6cZ2QGgCQ7xdOGhycLiwDECFcNAJrJhFticEstcdfk_eyRgpbFCFQvHGkwULHnH9fPKHCY&_nc_ohc=YVNQOr0w1Y0Q7kNvwHCqo_L&_nc_gid=_sfYE_Nh4MPaSWuCu90ThA&edm=APoiHPcBAAAA&ccb=7-5&ig_cache_key=MzQ4NTM5NjEzNDI0NTI0MTc5OQ%3D%3D.3-ccb7-5&oh=00_AfR0e0me0ZnKdMtVN4QWFtC5mD9sPnHItkvjCE9d7CUa-A&oe=6874419D&_nc_sid=22de04",
            "timestamp": "October 23, 2024"
        },
        {
            "caption": "Photo shared by Computer  Engineering Club Ensab on October 21, 2024 tagging @fakhredine_codes. Aucune description de photo disponible..",
            "image_url": "https://instagram.frak2-2.fna.fbcdn.net/v/t51.2885-15/464288673_17948239985855498_4696826766799195254_n.jpg?stp=dst-jpg_e35_tt6&efg=eyJ2ZW5jb2RlX3RhZyI6IkZFRUQuaW1hZ2VfdXJsZ2VuLjEwODB4MTA4MC5zZHIuZjc1NzYxLmRlZmF1bHRfaW1hZ2UifQ&_nc_ht=instagram.frak2-2.fna.fbcdn.net&_nc_cat=102&_nc_oc=Q6cZ2QFIh8Qq_7LZVVSpolSc-GzjfqDTcNOetB1sva7nWnJlR1p8RQKxzreLsc9Xo237g1M&_nc_ohc=QJmlBkOjdusQ7kNvwHxAMRe&_nc_gid=_sfYE_Nh4MPaSWuCu90ThA&edm=APoiHPcBAAAA&ccb=7-5&ig_cache_key=MzQ4Mzk2NjIwODc3ODU4NDY1NQ%3D%3D.3-ccb7-5&oh=00_AfSjH6eXwwTOm6mjdqFufkHi6JnSR7YHMUFI2LJ-oR95xA&oe=6874681B&_nc_sid=22de04",
            "timestamp": "October 21, 2024"
        },
        {
            "caption": "🚀 Nouvelle Collaboration : Formation en Développement Web avec Fakhredine ! 🚀\n\nNous sommes ravis d’annoncer notre collaboration avec Fakhredine, Full Stack Developer expérimenté, pour une formation en 3 sessions sur les bases du développement web ! 🌐\n\n💻 Session 1 : Découverte de HTML – Apprenez à structurer vos pages web.\n🎨 Session 2 : Plongée dans CSS – Maîtrisez l’art du design et du style web.\n💡 Session 3 : Introduction à JavaScript – Donnez vie à vos sites avec des interactions dynamiques.\n\nQue vous soyez débutant ou souhaitez renforcer vos compétences, cette formation est faite pour vous !  lancez-vous dans l’aventure du développement web.\n\nNe ratez pas cette opportunité d’apprendre avec un expert ! 🌟\n\n#FormationWeb #DéveloppementWeb #HTML #CSS #JavaScript #Apprentissage #collaboration \n#cec #cecensab_2024_2025 \n#RécapWorkshop #DéveloppementWeb #DéveloppementMobile #Apprentissage",
            "image_url": "https://instagram.frak2-2.fna.fbcdn.net/v/t51.2885-15/464094255_17948103770855498_1458548562097080875_n.jpg?stp=dst-jpg_e35_tt6&efg=eyJ2ZW5jb2RlX3RhZyI6IkNBUk9VU0VMX0lURU0uaW1hZ2VfdXJsZ2VuLjEwODB4MTA4MC5zZHIuZjc1NzYxLmRlZmF1bHRfaW1hZ2UifQ&_nc_ht=instagram.frak2-2.fna.fbcdn.net&_nc_cat=102&_nc_oc=Q6cZ2QGgCQ7xdOGhycLiwDECFcNAJrJhFticEstcdfk_eyRgpbFCFQvHGkwULHnH9fPKHCY&_nc_ohc=fqoeMEJ0qY0Q7kNvwFSYgM3&_nc_gid=_sfYE_Nh4MPaSWuCu90ThA&edm=APoiHPcBAAAA&ccb=7-5&ig_cache_key=MzQ4MzE4MDM0MDM5MjQ1Mzk4Nw%3D%3D.3-ccb7-5&oh=00_AfQZHEEtMCm4JPnUlmQfxNz6tyt_4dXLsDx5JBGSxtiNFA&oe=68745358&_nc_sid=22de04",
            "timestamp": null
        },
        {
            "caption": "Nous avons passé un excellent moment lors de notre workshop, où les participants ont découvert les bases passionnantes du développement web et mobile !\n\nUn grand merci à :\n@fatimzhra._.eljazouly pour son explication sur le Développement Web.\n@mohamedlouak pour sa présentation inspirante sur le Développement Mobile.\n\nMerci à tous ceux qui ont participé et contribué à la réussite de cet session . Restez connectés pour nos prochains événements ! 🚀\n\n#cec #cecensab_2024_2025 \n#RécapWorkshop #DéveloppementWeb #DéveloppementMobile #Apprentissage",
            "image_url": "https://instagram.frak2-2.fna.fbcdn.net/v/t39.30808-6/468074779_17952278864855498_5800944042182747261_n.jpg?stp=dst-jpg_e35_tt6&efg=eyJ2ZW5jb2RlX3RhZyI6IkNBUk9VU0VMX0lURU0uaW1hZ2VfdXJsZ2VuLjE0NDB4MTgwMC5zZHIuZjMwODA4LmRlZmF1bHRfaW1hZ2UifQ&_nc_ht=instagram.frak2-2.fna.fbcdn.net&_nc_cat=102&_nc_oc=Q6cZ2QGgCQ7xdOGhycLiwDECFcNAJrJhFticEstcdfk_eyRgpbFCFQvHGkwULHnH9fPKHCY&_nc_ohc=x0_IHxMfOKgQ7kNvwFOvnxS&_nc_gid=_sfYE_Nh4MPaSWuCu90ThA&edm=APoiHPcAAAAA&ccb=7-5&ig_cache_key=MzQ3NjAyMTEzNjQwNTU2OTAxMg%3D%3D.3-ccb7-5&oh=00_AfQjyRrLmBfrv0kRVU5O58zLFqWXbvWKz7clpBlsSl4LFQ&oe=68745FAA&_nc_sid=22de04",
            "timestamp": null
        },
        {
            "caption": "Photo by Computer  Engineering Club Ensab on October 08, 2024. Aucune description de photo disponible..",
            "image_url": "https://instagram.frak2-2.fna.fbcdn.net/v/t39.30808-6/468004311_17952278708855498_7634183504789816959_n.jpg?stp=dst-jpg_e35_tt6&efg=eyJ2ZW5jb2RlX3RhZyI6IkZFRUQuaW1hZ2VfdXJsZ2VuLjEwODB4MTA4MC5zZHIuZjMwODA4LmRlZmF1bHRfaW1hZ2UifQ&_nc_ht=instagram.frak2-2.fna.fbcdn.net&_nc_cat=102&_nc_oc=Q6cZ2QGgCQ7xdOGhycLiwDECFcNAJrJhFticEstcdfk_eyRgpbFCFQvHGkwULHnH9fPKHCY&_nc_ohc=I8EAImj9LNwQ7kNvwF1rMa_&_nc_gid=_sfYE_Nh4MPaSWuCu90ThA&edm=APoiHPcAAAAA&ccb=7-5&ig_cache_key=MzQ3NDU1MDM1NTc5MjI1NzcxNw%3D%3D.3-ccb7-5&oh=00_AfQ45WQ_L0O1qo3xBUmvxJttP4lGNa9YiihgRQYeCT7BYw&oe=68745F46&_nc_sid=22de04",
            "timestamp": "October 08, 2024"
        },
        {
            "caption": "Vous souhaitez acheter un ordinateur portable mais vous ne savez pas comment choisir celui qui correspond à vos besoins .\nVoilà une explication détaillée qui vous aidera à choisir un bon ordinateur selon vos préférences .\n\n.\n\n.\n\n#ComputerAndEngineeringClub  #TechCommunity #EngineeringSkills #JoinUs #NewBeginnings #cecensab_2024_2025",
            "image_url": "https://instagram.frak2-2.fna.fbcdn.net/v/t39.30808-6/468148084_17952278882855498_9152671985494957538_n.jpg?stp=dst-jpg_e35_tt6&efg=eyJ2ZW5jb2RlX3RhZyI6IkNBUk9VU0VMX0lURU0uaW1hZ2VfdXJsZ2VuLjEwODB4MTA4MC5zZHIuZjMwODA4LmRlZmF1bHRfaW1hZ2UifQ&_nc_ht=instagram.frak2-2.fna.fbcdn.net&_nc_cat=102&_nc_oc=Q6cZ2QGgCQ7xdOGhycLiwDECFcNAJrJhFticEstcdfk_eyRgpbFCFQvHGkwULHnH9fPKHCY&_nc_ohc=iWcBkvHRtO0Q7kNvwEQE6OU&_nc_gid=_sfYE_Nh4MPaSWuCu90ThA&edm=APoiHPcAAAAA&ccb=7-5&ig_cache_key=MzQ3MjM4OTY0MDcyNTczNTI2Mw%3D%3D.3-ccb7-5&oh=00_AfSO1R4tlV05hEL1Z8yt2IGnxqycX90bbewJcQIT0Cnog&oe=68746E18&_nc_sid=22de04",
            "timestamp": null
        },
        {
            "caption": "Photo by Computer  Engineering Club Ensab on September 26, 2024. Aucune description de photo disponible..",
            "image_url": "https://instagram.frak2-2.fna.fbcdn.net/v/t39.30808-6/468053741_17952278915855498_7469464469731617256_n.jpg?stp=dst-jpg_e35_tt6&efg=eyJ2ZW5jb2RlX3RhZyI6IkZFRUQuaW1hZ2VfdXJsZ2VuLjEwODB4MTA4MC5zZHIuZjMwODA4LmRlZmF1bHRfaW1hZ2UifQ&_nc_ht=instagram.frak2-2.fna.fbcdn.net&_nc_cat=102&_nc_oc=Q6cZ2QGgCQ7xdOGhycLiwDECFcNAJrJhFticEstcdfk_eyRgpbFCFQvHGkwULHnH9fPKHCY&_nc_ohc=U7256YU2TAYQ7kNvwGeKePv&_nc_gid=_sfYE_Nh4MPaSWuCu90ThA&edm=APoiHPcAAAAA&ccb=7-5&ig_cache_key=MzQ2NTcyNzk3MDQyMzIyNTM5Nw%3D%3D.3-ccb7-5&oh=00_AfT1fPxD4ujNBDycMG0bsb0buCoswPuJvaisyCx88zar4Q&oe=68746306&_nc_sid=22de04",
            "timestamp": "September 26, 2024"
        }
    ];

    const milestonesTrack = document.getElementById("milestones-track");
    const prevButton = document.querySelector(".carousel-button--prev");
    const nextButton = document.querySelector(".carousel-button--next");
    let currentIndex = 0;

    function createMilestoneCard(milestone) {
        const carouselItem = document.createElement("div");
        carouselItem.classList.add("carousel-item");

        const img = document.createElement("img");
        img.src = milestone.image_url;
        img.alt = milestone.caption;
        carouselItem.appendChild(img);

        const caption = document.createElement("p");
        caption.classList.add("carousel-item__caption");
        caption.textContent = milestone.caption;
        carouselItem.appendChild(caption);

        if (milestone.timestamp) {
            const timestamp = document.createElement("p");
            timestamp.classList.add("carousel-item__timestamp");
            timestamp.textContent = milestone.timestamp;
            carouselItem.appendChild(timestamp);
        }

        return carouselItem;
    }

    function renderMilestones() {
        milestonesTrack.innerHTML = "";
        milestonesData.forEach(milestone => {
            milestonesTrack.appendChild(createMilestoneCard(milestone));
        });
        updateCarousel();
    }

    function updateCarousel() {
        const itemWidth = milestonesTrack.children[0].offsetWidth;
        milestonesTrack.style.transform = `translateX(${-currentIndex * itemWidth}px)`;
    }

    prevButton.addEventListener("click", () => {
        currentIndex = (currentIndex > 0) ? currentIndex - 1 : milestonesData.length - 1;
        updateCarousel();
    });

    nextButton.addEventListener("click", () => {
        currentIndex = (currentIndex < milestonesData.length - 1) ? currentIndex + 1 : 0;
        updateCarousel();
    });

    // Initial render
    renderMilestones();

    // Update carousel on window resize
    window.addEventListener("resize", updateCarousel);
});


